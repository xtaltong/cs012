#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <ostream>
#include <algorithm>

using namespace std;

#include "Deck.cpp"
#include "Card.cpp"

bool hasPair(const vector<Card> &hand);
ostream & operator<<(ostream &out, const vector<Card> &d){
    for(unsigned i = 0; i < d.size() - 1; i++){
        out << d.at(i) << ", ";
    }
    out << d.at(d.size()-1);
    
    return out;
}

int main() {
    srand(2222);
    string ans = ""
    string fileName = "";
    int numCards = 0;
    int numDeals = 0;
    int deals = 0;
    double percent;
    ofstream fout;
    vector <Card> hand;
    vector <int> deck;
    Deck myDeck;
    
    cout << "Do you want to output all hands to a file?(Yes/No) ";
    cin >> ans;
    cout << endl;
    cout << endl;
    
    if(ans == "Yes" || ans == "yes"){
        cout << "Enter name of output file: ";
        cin >> fileName;
        cout << endl;
        cout << endl;
        
        fout.open(fileName.c_str());
        
        if(!fout.is_open()){
            cout << "Error opening file: " << fileName << endl;
            
            return 1;
        }
    }
    cout << "Enter number of cards per hand: ";
    cin >> numCards;
    cout << endl;
    
    cout << "Enter number of deals (simulations): ";
    cin >> numDeals;
    cout << endl;
    
    int pair = 0;
    if(ans == "Yes" || ans == "yes"){
        while(deals < numDeals){
            myDeck.shuffleDeck();
            
            for(unsigned i = 0; i < numCards; i++){
                hand.push_back(myDeck.dealCard());
            }
            if(hasPair(hand) == true){
                pair++;
                fout << "Found Pair!! " << hand.at(0) << ", ";
                for(unsigned j = 1; j < hand.size()-1; j++){
                    fout << hand.at(j) << ", ";
                }
                fout << hand.at(hand.size()-1);   
            }
            else{
                fout << "\t\t\t" << hand.at(0);
                
                for(unsigned j = 0; j < hand.size()-1; j++){
                    fout << hand.at(j) << ", ";
                }
                fout << hand.at(hand.size()-1);
            }
            deals++;
            hand.clear();
        }
        fout.close();
    }
    else{
        while(deals < numDeals){
            myDeck.shuffleDeck();
            
            for(unsigned i = 0; i < numCards; i++){
                hand.push_back(myDeck.dealCard());
            }
            if(hasPair(hand) == true){
                pair++;
            }
            deals++;
            hand.clear();
        }
    }
    
    percent = ((pair*1.0)/(numDeals*1.0))*100.0;
    
    fout.close();
    
    cout << "Chances of receiving a pair in a hand of " << numCards << " cards is: " << percent << "%" << endl;
    
    return 0;
}

bool hasPair(const vector<Card> &hand){
    bool isPair = false;
    for(unsigned i = 0; i < hand.size()-1; i++){
       for(unsigned j = i+1; j < hand.size(); j++){
           if(hand[i].getRank() == hand[j].getRank()){
               isPair = true;
           }
       } 
    }
    return isPair;
}
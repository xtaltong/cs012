#include <iostream>

using namespace std;

#include "Card.h"
Card::Card(){
    suit = 'c';
    rank = 2;
}
	
Card::Card(char s, int r){
    suit = tolower(s);
    if((suit == 'c') || (suit == 'd') || (suit == 'h') || (suit == 's')){
        suit = s;
    }
    else{
        suit = 'c';
    }
    if(r > 0 && r < 14){
        rank = r;
    }
    else{
        rank = 2;
    }
}

char Card::getSuit() const{
    return suit;
}
	
int Card::getRank() const{
    return rank;
}
	
ostream & operator<<(ostream &out, const Card &rhs){
    if(rhs.rank == 1){
        out << "Ace";
    }
    else if(rhs.rank == 11){
        out << "Jack";
    }
    else if(rhs.rank == 12){
        out << "Queen";
    }
    else if(rhs.rank == 13){
        out << "King";
    }
    else{
        out << rhs.rank;
    }
    
    out << " of ";
    
    if(rhs.suit == 'c'){
        out << "Clubs";
    }
    else if(rhs.suit == 'd'){
        out << "Diamonds";
    }
    else if(rhs.suit == 'h'){
        out << "Hearts";
    }
    else if(rhs.suit == 's'){
        out << "Spades";
    }
    
    return out;
}

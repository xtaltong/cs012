#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

#include "Deck.h"
    /* Constructs a Deck of 52 cards:
       Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, King of each suit.
       Cards should start off in this order with the order of suits being:
       Clubs, Diamonds, Hearts, Spades.
    */
Deck::Deck(){

 theDeck.resize(52);
 unsigned j = theDeck.size()-1;
 for(unsigned i = 1; i <= 13; i++){
  if((i >= 1) && (i <= 13)){
   theDeck.at(j) = Card('c',i);
   j = j-1;
  }
 }
 for(unsigned i = 1; i <= 13; i++){
  if((i >= 1) && (i <= 13)){
   theDeck.at(j) = Card('d',i);
   j = j-1;
  }
 }
 for(unsigned i = 1; i <= 13; i++){
  if((i >= 1) && (i <= 13)){
   theDeck.at(j) = Card('h',i);
   j = j-1;
  }
 }
 for(unsigned i = 1; i <= 13; i++){
  if((i >= 1) && (i <= 13)){
   theDeck.at(j) = Card('s',i);
   j=j-1;
  }
 }
}

    /* Deals (returns) the top card on the deck. 
       Removes this card from theDeck and places it in the dealtCards.
    */
Card Deck::dealCard(){
    Card dealtCard = theDeck.back();
    dealtCards.push_back(dealtCard);
    theDeck.pop_back();
   
   return dealtCard; 
}


    /* Places all cards back into theDeck and shuffles them into random order.
    */
void Deck::shuffleDeck() {
    for(unsigned i = 0; i < dealtCards.size(); i++){
        theDeck.push_back(dealtCards.at(i));
    }
    dealtCards.clear();
    random_shuffle(theDeck.begin(), theDeck.end());
}
    /* returns the size of the Deck (how many cards have not yet been dealt).
    */
unsigned Deck::deckSize() const {
    return theDeck.size();
}




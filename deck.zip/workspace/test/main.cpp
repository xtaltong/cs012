#include <iostream> 

using namespace std;

int main() {
    for(int i = 1; i <= 52; i++) {
        cout << i << endl;
        if(i % 13 == 0) {
            cout << "one suit" << endl;
        }
    } 
    return 0;
}
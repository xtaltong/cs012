#include <iostream>
#include "IntVector.h"

using namespace std; 

int main() {
    int index;
    IntVector please = IntVector(10);

    cout << "What is the size?" << endl;
    
    cout << please.size() << endl;
    
    cout << "What is the capacity?" << endl;
    
    cout << please.capacity() << endl;
    
    cout << "Is the array empty?" << endl;
    
    if(please.empty()) {
        cout << "Yes it is" << endl;
    }
    else {
        cout << "No it's not" << endl;
    }
    
    for(unsigned i = 0; i < please.size(); i++) {
        please.at(i) = i + 1;
        cout << please.at(i) << " ";
    }
    cout << endl;
    
    cout << "Enter the index you want to see." << endl;

    cin >> index;
    
    cout << "The number at " << index << " is: ";
    cout << please.at(index) << endl;
    cout << "The number at the front is: ";
    cout << please.front() << endl;
    cout << "The number at the end is: ";
    cout << please.back() << endl;
    
    please.push_back(11);
    please.erase(3);
    please.insert(4, 5);

    for(unsigned i = 0; i < please.size(); i++) {
        cout << please.at(i) << " ";
    }
    cout << endl << endl;
    
    cout << "Calling pop_back()" << endl;
    
    please.pop_back();
    
    for(unsigned i = 0; i < please.size(); i++) {
        cout << please.at(i) << " ";
    }
    cout << endl << endl;
    
    cout << "Calling resize()" << endl;
    
    please.resize(15, 3);
    
    for(unsigned i = 0; i < please.size(); i++) {
        cout << please.at(i) << " ";
    }
    cout << endl << endl;
    
    cout << "Calling clear()" << endl;
    
    please.clear();
    
    cout << "What is the size?" << endl;
    
    cout << please.size() << endl;
    
    cout << "What is the capacity?" << endl;
    
    cout << please.capacity() << endl;
    
    cout << "Is the array empty?" << endl;
    
    if(please.empty()) {
        cout << "Yes it is" << endl;
    }
    else {
        cout << "No it's not" << endl;
    }
    cout << endl;
    
}
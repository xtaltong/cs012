#include <iostream>
#include "IntVector.h"

using namespace std; 

int main() {
    
    cout << "What is the size?" << endl;
    
    cout << IntVector(10).size() << endl;
    
    cout << "What is the capacity?" << endl;
    
    cout << IntVector(10).capacity() << endl;
    
    cout << "Is the array empty?" << endl;
    
    if(IntVector(10).empty()) {
        cout << "Yes it is" << endl;
    }
    else {
        cout << "No it's not" << endl;
    }
    
    int index;
    cin >> index;
    
    cout << IntVector(10).at(index) << endl;
    cout << IntVector(10).front() << endl;
    cout << IntVector(10).back() << endl;
}